package com.cg.assi;

public class Client {

	public static void main(String[] args) {
		

	}

}
