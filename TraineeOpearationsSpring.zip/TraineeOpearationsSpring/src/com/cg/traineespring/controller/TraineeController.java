package com.cg.traineespring.controller;

import java.util.ArrayList;

import org.springframework.ui.Model;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.traineespring.bean.Trainee;
import com.cg.traineespring.exception.TraineException;
import com.cg.traineespring.service.TraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	Trainee bean;
	
	@Autowired
	TraineeService service;
	
	Trainee traineeDetails;
	
	@RequestMapping("/showLogInPage")
	public String showLogin()
	{
		return "login";
	}
	
	@RequestMapping("/checkValidation")
	public String checkValidation(@RequestParam("user")String user,@RequestParam("password")String password,Model model)
	{
		if(user.equals("admin") && password.equals("admin"))
		{
			return "home";
		}
		else
		{
			model.addAttribute("message", "Sorry..User Name or Password is incorrect");
			return "login";
		}
		
	}
	
	@RequestMapping("/addTrainee")
	public String addTrainee(Model model)
	{
		ArrayList<String> domainList = new ArrayList<String>();
		domainList.add("JEE");
		domainList.add(".NET");
		domainList.add("C++");
		domainList.add("PHP");
		domainList.add("Object C");
		domainList.add("Big Data");
		
		model.addAttribute("domainList", domainList);
		model.addAttribute("bean", bean);
		return "newTrainee";
	}
	
	@RequestMapping("/newTrainee")
	public String newTrainee(Trainee bean,Model model)
	{
		//System.out.println(bean.getTraineeLocation());
		try {
			
			service.insertTrainee(bean);
			return "home";
			
		} catch (TraineException e) {
			// TODO Auto-generated catch block
			model.addAttribute("exception", e.getMessage());
			return "error";
		}
		
	}
	
	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model)
	{
		model.addAttribute("bean", bean);
		return "deleteTrainee";
	}
	
	@RequestMapping("/removeTrainee")
	public String removeTrainee(Trainee bean,Model model)
	{
		try {
			traineeDetails = service.getTrainee(bean.getTraineeId());
			
			/*String tab="<table border=\"1\"><tr><td>Trainee ID</td><td>Trainee Name</td><td>Trainee Location</td><td>Trainee Location</td></tr>";
			model.addAttribute("table", tab);*/
			
			/*String button="<td><input type=\"submit\" value=\"Delete\"/></td></table>";
			model.addAttribute("button", button);*/
			
			/*model.addAttribute("heading", "Trainee Info");*/
			model.addAttribute("bean", bean);
			model.addAttribute("traineeDetails", traineeDetails);
			
			return "deleteTrainee";
			
		} catch (TraineException e) {
			// TODO Auto-generated catch block
			model.addAttribute("exception", e.getMessage());
			return "error";
		}
		
	}
	
	@RequestMapping("/remove1Trainee")
	public String remove1Trainee(Model model)
	{
		try {
			
			service.removeTrainee(traineeDetails.getTraineeId());
			
			return "home";
			
		} catch (TraineException e) {
			// TODO Auto-generated catch block
			
			model.addAttribute("exception", e.getMessage());
			return "error";
		}
		
	}
	
	@RequestMapping("/modifyTrainee")
	public String modifyTrainee(Model model)
	{
		model.addAttribute("bean", bean);
		return "modifyTrainee";
	}
	
	@RequestMapping("/modify1Trainee")
	public String modify1Trainee(Trainee bean,Model model)
	{
		System.out.println(bean.getTraineeId());
		try {
			traineeDetails = service.getTrainee(bean.getTraineeId());
			
			String tab1="<table border=\"1\"><tr><td>Trainee ID</td>";
			String tab2="</tr><tr><td>Trainee Name</td>";
			String tab3 = "</tr><tr><td>Trainee Location</td>";
			String tab4="</tr><tr><td>Trainee Domain</td>";
			model.addAttribute("table1", tab1);
			model.addAttribute("type1", "text");
			model.addAttribute("table2", tab2);
			model.addAttribute("type2", "text");
			model.addAttribute("table3", tab3);
			model.addAttribute("type3", "text");
			model.addAttribute("table4", tab4);
			model.addAttribute("type4", "text");
			model.addAttribute("last", "</tr>");
			
			String button="<td><input type=\"submit\" value=\"update\"/></td></table>";
			model.addAttribute("button", button);
			
			model.addAttribute("heading", "Trainee Info");
			model.addAttribute("bean", bean);
			model.addAttribute("traineeDetails", traineeDetails);
			return "modifyTrainee";
			
		} catch (TraineException e) {
			// TODO Auto-generated catch block
			model.addAttribute("exception", e.getMessage());
			return "error";
		}
		
	}
	
	@RequestMapping("/modify2Trainee")
	public String modify2Trainee(Trainee bean,Model model)
	{
		System.out.println(bean.getTraineeLocation());
		
		try {
			
			service.modifyTrainee(bean);
			return "home";
	
		} catch (TraineException e) {
			// TODO Auto-generated catch block
			model.addAttribute("exception", e.getMessage());
			return "error";
		}

	}
	
	@RequestMapping("/retrieveTrainee")
	public String retrieveTrainee(Model model)
	{
		model.addAttribute("bean", bean);
		return "retrieveTrainee";
	}
	
	@RequestMapping("/retrieve1Trainee")
	public String retrieve1Trainee(Trainee bean,Model model)
	{
		try {
			traineeDetails = service.getTrainee(bean.getTraineeId());
			String tab="<table border=\"1\"><tr><td>Trainee ID</td><td>Trainee Name</td><td>Trainee Location</td><td>Trainee Domain</td></tr>";
			model.addAttribute("table", tab);
				
				
			model.addAttribute("heading", "Trainee Info");
			model.addAttribute("bean", bean);
			model.addAttribute("traineeDetails", traineeDetails);
			return "retrieveTrainee";
			
		} catch (TraineException e) {
			// TODO Auto-generated catch block
			model.addAttribute("exception", e.getMessage());
			return "error";
		}
		
		
		
	}
	
	@RequestMapping("/retrieveAllTrainee")
	public String retrieveAllTrainee(Model model)
	{
		ArrayList<Trainee> list = null;
		try {
			list = service.getAllTrainee();
			model.addAttribute("traineeList", list);
			return "retrieveAllTrainee";
		} catch (TraineException e) {
			// TODO Auto-generated catch block
			model.addAttribute("exception", e.getMessage());
			return "error";
		}
		
	}
}
