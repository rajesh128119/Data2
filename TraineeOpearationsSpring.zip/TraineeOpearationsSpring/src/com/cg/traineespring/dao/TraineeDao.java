package com.cg.traineespring.dao;

import java.util.ArrayList;

import com.cg.traineespring.bean.Trainee;
import com.cg.traineespring.exception.TraineException;

public interface TraineeDao {
	public void insertTrainee(Trainee bean) throws TraineException;
	public Trainee removeTrainee(int id) throws TraineException;
	public Trainee getTrainee(int id) throws TraineException;
	public Trainee modifyTrainee(Trainee bean) throws TraineException;
	public ArrayList<Trainee> getAllTrainee() throws TraineException;
}
