package com.cg.traineespring.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.traineespring.bean.Trainee;
import com.cg.traineespring.exception.TraineException;

@Repository
public class TraineeDaoImpl implements TraineeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public void insertTrainee(Trainee bean) throws TraineException{
		// TODO Auto-generated method stub
		Trainee trainee = entityManager.find(Trainee.class, bean.getTraineeId());
		if(trainee!=null)
		{
			throw new TraineException("Trainee Id "+bean.getTraineeId()+" already exist.Please enter other Id");
		}
		else
		{
			entityManager.persist(bean);
			entityManager.flush();
		}
	}

	@Override
	public Trainee removeTrainee(int id) throws TraineException{
		// TODO Auto-generated method stub
		Trainee bean = entityManager.find(Trainee.class, id);
		entityManager.remove(bean);
		if(bean==null)
		{
			throw new TraineException("Failed to Remove Trainee.. Because Trainee is Not Found for Id"+id);
		}
		return bean;
	}

	@Override
	public Trainee getTrainee(int id) throws TraineException{
		// TODO Auto-generated method stub
		Trainee bean = entityManager.find(Trainee.class, id);
		if(bean==null)
		{
			throw new TraineException("Trainee Not Found for Id"+id);
		}
		return bean;
	}

	@Override
	public Trainee modifyTrainee(Trainee bean) throws TraineException{
		// TODO Auto-generated method stub
		Trainee bean1 = entityManager.find(Trainee.class, bean.getTraineeId());
		bean1.setTraineeId(bean.getTraineeId());
		bean1.setTraineeName(bean.getTraineeName());
		bean1.setTraineeLocation(bean.getTraineeLocation());
		bean1.setTraineeDomain(bean.getTraineeDomain());
		
		entityManager.persist(bean1);
		entityManager.flush();
		
		if(bean1==null)
		{
			int id = bean1.getTraineeId();
			throw new TraineException("Filed To modify"+id);
		}
		
		/*String qStr = "UPDATE Trainee trainee SET trainee.traineeId=:id,trainee.traineeName=:name,trainee.traineeDomain=:domain,trainee.traineeLocation=:location WHERE trainee.traineeId=:id";
		TypedQuery<Trainee> query = entityManager.createQuery(qStr, Trainee.class);
		query.setParameter("id", bean.getTraineeId());
		query.setParameter("name", bean.getTraineeName());
		query.setParameter("domain", bean.getTraineeDomain());
		query.setParameter("location", bean.getTraineeLocation());
		query.
		return bookList;*/
		/*System.out.println(bean.getTraineeName());
		entityManager.merge(bean);*/
		
		return bean;
	}

	@Override
	public ArrayList<Trainee> getAllTrainee() throws TraineException{
		// TODO Auto-generated method stub
		ArrayList<Trainee> list = new ArrayList<Trainee>();
		String qStr = "SELECT trainee FROM Trainee trainee";
		TypedQuery<Trainee> query = entityManager.createQuery(qStr, Trainee.class);
		list = (ArrayList<Trainee>) query.getResultList();
		
		if(list.size()==0)
		{
			throw new TraineException("Records Are not available");
		}
		
		return list;
	}

}
