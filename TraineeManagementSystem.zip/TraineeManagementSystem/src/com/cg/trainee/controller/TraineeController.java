package com.cg.trainee.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;
import com.cg.trainee.service.TraineeService;

@Controller
public class TraineeController {
	
	@Autowired
	TraineeService traineeService;
	@Autowired
	Trainee trainee;
	
	Trainee traineeDetail;
	List<String> domain;
	
	@RequestMapping(value="/login")
	public String validateLogin()
	{
		
			return "Login";
		
	}
	
	@RequestMapping(value="/operations")
	public String performOpeartions(@RequestParam("uName") String userName, @RequestParam("pwd") String password, Model model)
	{
				
		if(userName.equals("admin") && password.equals("admin"))
		{
			return "Operations";
		}
		else
		{
			model.addAttribute("logfail","Check user name and password");
			
			return "Login";
		}
		
	}
	
	@RequestMapping(value="/add")
	public String addTrainee(Model model)
	{
		domain = new ArrayList<String>();
		domain.add("JEE");
		domain.add(".NET");
		domain.add("MainFrame");
		domain.add("Testing");
		
		model.addAttribute("domain",domain);
		model.addAttribute("trainee", trainee);
		

		return "Add";
			
	}
	
	@RequestMapping(value="/added")
	public String addedTrainee(@ModelAttribute("trainee")@Valid Trainee trainee,BindingResult result, Model model) 
	{
		boolean add = false;
		
		if(result.hasErrors())
		{
			model.addAttribute("domain",domain);
			return "Add";
		}
		else
		{
		
		try {
			
			add = traineeService.addTrainee(trainee);
		} catch (TraineeException e) {
			
			
			model.addAttribute("message",e.getMessage());
			return "Fail";
		}
		
		if(add)
		{
			return "Success";
		}
		else {
			return "Fail";
		}
		
		}
		
	}
	
		
	@RequestMapping(value="/delete")
	public String deleteTrainee(Model model) 
	{
		
		model.addAttribute("traineeId",trainee);
		
		
		
		return "Delete";
		
		
	}
	
	@RequestMapping(value="/showDataToDelete")
	public String showDataToDelete(@ModelAttribute("traineeId") Trainee trainee, Model model)
	{
		
		traineeDetail=new Trainee();
		int traineeId = trainee.getTraineeId();
		
		
		try {
			traineeDetail=traineeService.getTraineeById(traineeId);
			model.addAttribute("traineeDetail",traineeDetail);
			
			
		
		} catch (TraineeException e) {
			
			
			model.addAttribute("message",e.getMessage());
			return "Fail";
			
			
		}
		
		
		return "Delete";
		
	}
	
	@RequestMapping(value="/deleted")
	public String deletedTrainee(Model model) 
	{
		
		int traineeId = traineeDetail.getTraineeId();
		
		boolean delete = false;
		try {
			
			delete = traineeService.deleteTrainee(traineeId);
			
		} catch (TraineeException e) {
			
			
			model.addAttribute("message",e.getMessage());
			return "Fail";
		}
		
		if(delete)
		{
			return "Success";
		}
		else {
			return "Fail";
		}
		
		
	}
	
	@RequestMapping(value="/modify")
	public String modifyTraineeById(Model model)
	{
		
		model.addAttribute("trainee",trainee);
		
		return "Modify";
		
	}
	
	@RequestMapping(value="/showDataToModify")
	public String showDataToModify(@ModelAttribute("trainee") Trainee trainee, Model model)
	{
		
		int traineeId = trainee.getTraineeId();
		
		try {
			traineeDetail=traineeService.getTraineeById(traineeId);
			model.addAttribute("traineeDetail",traineeDetail);
		
		} catch (TraineeException e) {
			
			model.addAttribute("message",e.getMessage());
			return "Fail";
		}
		
		return "Modify";
		
	}
	
	@RequestMapping(value="/modified")
	public String modifiedTrainee(@ModelAttribute("traineeDetail")Trainee trainee,Model model) 
	{
		
		boolean modify = false;
		try {
			
			modify = traineeService.modifyTrainee(trainee);
		} catch (TraineeException e) {
			
			
			model.addAttribute("message",e.getMessage());
			return "Fail";
		}
		
		if(modify)
		{
			return "Success";
		}
		else {
			return "Fail";
		}
		
		
	}
	
	@RequestMapping(value="/retrieve")
	public String getTraineeById(Model model)
	{
		model.addAttribute("trainee",trainee);	
		return "SingleTraineeDetail";
		
	}
	
	
	
	@RequestMapping(value="/retrieveAll")
	public String getAllTrainee(Model model)
	{
		ArrayList<Trainee> traineeList=new ArrayList<Trainee>();
		
		try {
			traineeList=traineeService.getAllTrainee(trainee);
			model.addAttribute("traineeList",traineeList);
			
		} catch (TraineeException e) {
			
			model.addAttribute("message",e.getMessage());
			return "Fail";
		}
		
		
		return "AllTraineeDetails";
	}
	
	
	
	@RequestMapping(value="/showById")
	public String showTraineeById(@ModelAttribute("trainee")Trainee trainee,Model model)
	{
		
		Trainee traineeDetail=new Trainee();
		
		try {
			traineeDetail=traineeService.getTraineeById(trainee.getTraineeId());
			model.addAttribute("traineeDetail",traineeDetail);
			
		
		} catch (TraineeException e) {
			
			
			model.addAttribute("message",e.getMessage());
			return "Fail";
		}
		
		return "SingleTraineeDetail";
		
		
	}
	
}
