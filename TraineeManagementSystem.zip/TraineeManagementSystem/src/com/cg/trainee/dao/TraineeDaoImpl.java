package com.cg.trainee.dao;

import java.util.ArrayList;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;

@Repository
public class TraineeDaoImpl implements TraineeDao{
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public boolean addTrainee(Trainee trainee) throws TraineeException {
		// TODO Auto-generated method stub
		
		entityManager.persist(trainee);
		
		return true;
	}

	@Override
	public ArrayList<Trainee> getAllTrainee(Trainee trainee)
			throws TraineeException {
		// TODO Auto-generated method stub
		ArrayList<Trainee> list= new ArrayList<Trainee>();
		String qString="SELECT trainee FROM Trainee trainee";
		TypedQuery<Trainee> tq = entityManager.createQuery(qString,Trainee.class);
		list=(ArrayList<Trainee>) tq.getResultList();
		
		if(list.size()==0)
		{
			throw new TraineeException("Trainees are not available");
		}
		
		return list;
	}

	@Override
	public Trainee getTraineeById(int traineeId) throws TraineeException {
		// TODO Auto-generated method stub
		Trainee trainee=new Trainee();
		
		trainee=entityManager.find(Trainee.class, traineeId);
		/*String qString="SELECT trainee FROM Trainee trainee WHERE trainee.traineeId=:traineeId";
		
		TypedQuery<Trainee> tq = entityManager.createQuery(qString,Trainee.class);
		tq.setParameter("traineeId", traineeId);
		trainee=tq.getSingleResult();*/
		
		if(trainee==null)
		{
			throw new TraineeException("No trainee details found for "+traineeId);
		}
		
		return trainee;
	
		
	}
	@Override
	public boolean deleteTrainee(int traineeId) throws TraineeException {
		// TODO Auto-generated method stub
		boolean flag=false;
		
		Trainee trainee=new Trainee();
		trainee=entityManager.find(Trainee.class, traineeId);
		
		if(trainee==null)
		{
			flag=false;
			throw new TraineeException("Trainee details not found for "+traineeId);
			
		}
		else
		{
		entityManager.remove(trainee);
		flag=true;
		}
		return flag;
	}

	@Override
	public boolean modifyTrainee(Trainee trainee) throws TraineeException {
		// TODO Auto-generated method stub
		boolean flag = false;
		Trainee trainee1 =new Trainee();
		
		int traineeId = trainee.getTraineeId();
		
		trainee1=entityManager.find(Trainee.class, traineeId);
		/*trainee2.setTraineeId(trainee.getTraineeId());
		trainee2.setTraineeName(trainee.getTraineeName());
		trainee2.setTraineeLocation(trainee.getTraineeLocation());
		trainee2.setTraineeDomain(trainee.getTraineeDomain());*/
		if(trainee1 == null)
		{
			flag = false;
			throw new TraineeException("Trainee details not found for "+traineeId);
			
		}
		else
		{
		entityManager.merge(trainee);
		entityManager.flush();
		flag = true;
		}
		return flag;
	}

}
