package com.cg.trainee.dao;

import java.util.ArrayList;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;

public interface TraineeDao {

	boolean addTrainee(Trainee trainee) throws TraineeException;

	ArrayList<Trainee> getAllTrainee(Trainee trainee)throws TraineeException;

	Trainee getTraineeById(int traineeId)throws TraineeException;

	boolean deleteTrainee(int traineeId)throws TraineeException;

	boolean modifyTrainee(Trainee trainee)throws TraineeException;

}
