package com.cg.trainee.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.stereotype.Component;



@Entity
@Component
public class Trainee {
	
	@Id
	@NotNull
	@Range(min=1001,message="Trainee id should be more than 1000 ")
	private int traineeId;
	@NotEmpty(message="Trainee name is mandatory")
	@Pattern(regexp="[A-Z]{1}[a-z]{2,20}", message="First word should be capital and minimum three letters are required")
	//@Size(min=4,max=8,message="Minimum 4 and Maximum 8 characters required")
	private String traineeName;
	@NotEmpty(message="Trainee Domain is mandatory")
	private String traineeDomain;
	@NotEmpty(message="Trainee Location is mandatory")
	private String traineeLocation;
	
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

}
