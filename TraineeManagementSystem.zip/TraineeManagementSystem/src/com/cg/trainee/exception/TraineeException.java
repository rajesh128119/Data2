package com.cg.trainee.exception;

public class TraineeException extends Exception{

	String message;
	
	public TraineeException(String msg)
	{
		this.message = msg;
	}
	@Override
	public String getMessage()
	{
		return message;
	}
}
