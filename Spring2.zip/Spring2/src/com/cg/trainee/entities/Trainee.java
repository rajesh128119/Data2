package com.cg.trainee.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.stereotype.Component;


@Entity
@Component
@Table (name="trainee")
public class Trainee implements Serializable{

/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

@NotNull
@Range(min=1000,message="TraineeId should be more than 1000")
@Id
@Column(name="traineeId")
private int traineeId;


@NotEmpty(message="Trainee name should not be empty")
@Pattern(regexp="[A-Z]{1}[a-z]{2,20}",message="First word should be capital and min 3 , max 21 letters allowed")
@Column(name="traineeName")
private String traineeName;

@NotEmpty(message="Trainee domain is mandatory")
@Column(name="traineeDomain")
private String traineeDomain;

@NotEmpty (message="Trainee Location is mandatory")
@Column(name="traineeLocation")
private String traineeLocation;



public Trainee() {
	super();
}
public int getTraineeId() {
	return traineeId;
}
public void setTraineeId(int traineeId) {
	this.traineeId = traineeId;
}
public String getTraineeName() {
	return traineeName;
}
public void setTraineeName(String traineeName) {
	this.traineeName = traineeName;
}
public String getTraineeDomain() {
	return traineeDomain;
}
public void setTraineeDomain(String traineeDomain) {
	this.traineeDomain = traineeDomain;
}
public String getTraineeLocation() {
	return traineeLocation;
}
public void setTraineeLocation(String traineeLocation) {
	this.traineeLocation = traineeLocation;
}
@Override
public String toString() {
	return "Trainee [traineeId=" + traineeId + ", traineeName=" + traineeName
			+ ", traineeDomain=" + traineeDomain + ", traineeLocation="
			+ traineeLocation + "]";
}


}
