package com.cg.trainee.exception;

public class TraineeException extends Exception {
String message;

public TraineeException(String message) {
	this.message = message;
}

public String getMessage() {
	return message;
}


}
