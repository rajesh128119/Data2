package com.cg.trainee.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;

public interface ITraineeRepositoryDao {
	boolean addTrainee(Trainee trainee) throws TraineeException;
	public boolean modifyTrainee(Trainee trainee);
	public Trainee retrieveTrainee(int traineeId);
	public ArrayList<Trainee> retrieveAllTrainee();
	boolean deleteTrainee(int traineeId);
	

}
