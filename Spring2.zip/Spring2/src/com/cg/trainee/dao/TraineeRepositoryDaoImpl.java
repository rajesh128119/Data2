package com.cg.trainee.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;

@Repository
public class TraineeRepositoryDaoImpl implements ITraineeRepositoryDao {
@PersistenceContext
EntityManager em;

@Autowired 
Trainee trainee;


	@Override
	public boolean addTrainee(Trainee trainee)throws TraineeException {
		boolean flag = false; 
		
		Trainee bean = em.find(Trainee.class,  trainee.getTraineeId());
		
		if(bean!=null)
		{
			throw new TraineeException("Record already present of entered Id");
		}
		else
		{
			em.persist(trainee);//obj of bean in which we want to insert data
			em.flush();
			flag = true;
		}
		
		return flag;
	}


	@Override
	public Trainee retrieveTrainee(int traineeId) {
		Trainee trainee=em.find(Trainee.class, traineeId);
		return trainee;
	}

	@Override
	public ArrayList<Trainee> retrieveAllTrainee() {
		ArrayList<Trainee> list=new ArrayList<Trainee>();
		TypedQuery<Trainee> tq=em.createQuery("SELECT trainee FROM Trainee trainee",Trainee.class);
		return (ArrayList<Trainee>) tq.getResultList();
	}


	@Override
	public boolean deleteTrainee(int traineeId) {
		Trainee trainee=em.find(Trainee.class, traineeId);	
		em.remove(trainee);
		return true;
	}

	@Override
	public boolean modifyTrainee(Trainee trainee) {

		System.out.println(trainee);
		Trainee tr1 = em.merge(trainee);
		System.out.println(tr1);
		if(tr1!=null)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
}
