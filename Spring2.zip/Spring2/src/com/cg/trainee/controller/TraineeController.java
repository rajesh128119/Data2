package com.cg.trainee.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;
import com.cg.trainee.service.ITraineeService;
import com.sun.xml.internal.org.jvnet.staxex.NamespaceContextEx.Binding;

@Controller
public class TraineeController {
	@Autowired
	private ITraineeService ITraineeService;
	
	@Autowired
	Trainee trainee;
	
	@RequestMapping (value="/login")
	public String showLoginPage(){
		return "login";
	}
	

	@RequestMapping (value="/traineemanage")
	public String validLoginPage(@RequestParam("userName") String userName,@RequestParam("password")String password,Model model){
	if(userName.equals("admin") & password.equals("password")){
		return "traineemanage";
	}
	else{
		model.addAttribute("logfail","Please check login id and password");
		return "login";
	}
	}
	
	
	
	@RequestMapping (value="/addTraineeDetails")
	public String addTrainee(Model model){
		
		ArrayList<String> domain=new ArrayList<String>();
		domain.add("JEE");
		domain.add(".NET");
		domain.add("MainFrame");
		domain.add("testing");
		model.addAttribute("trainee", trainee);
		model.addAttribute("domain",domain);
		return "TraineeDetailForm";
	}
	
	

	@RequestMapping (value="/add")
	public String showTraineeDetails(@ModelAttribute("trainee")@Valid Trainee trainee,BindingResult result,Model model){
		System.out.println(trainee);
		
		if(result.hasErrors()){
			ArrayList<String> domain=new ArrayList<String>();
			domain.add("JEE");
			domain.add(".NET");
			domain.add("MainFrame");
			domain.add("testing");
			model.addAttribute("trainee", trainee);
			model.addAttribute("domain",domain);
			return "TraineeDetailForm";
		}
		else{
		/*boolean add=false;*/
		try {
			
			ITraineeService.addTrainee(trainee);
			return "added";
			
		} catch (TraineeException e) {
			// TODO Auto-generated catch block

			model.addAttribute("exception", e.getMessage());
			return "error";
		}
		
		
		}
	}	
	
	@RequestMapping (value="/getTraineeId")
	public String showTakingTraineeId(Model model){
		model.addAttribute("traineeId",trainee);
		return  "traineeById";
	}
	
		
	@RequestMapping(value="/retrieve")
	public String showTraineeDetails(@ModelAttribute("traineeId") Trainee trainee,Model model){
		
		trainee=ITraineeService.retrieveTrainee(trainee.getTraineeId());
		model.addAttribute("trainee",trainee );
		return "traineeDetails";
		
	}
	
	
	

	@RequestMapping (value="retrieveTrainee")
	public String showTraineeData(Trainee trainee,Model model){
		 int traineeId = trainee.getTraineeId();
		 trainee = ITraineeService.retrieveTrainee(traineeId);
		 
		model.addAttribute("traineeDetails", trainee);
		
		return "traineeDetails";
	}
	
	@RequestMapping (value="retrieveall")
	public String showAllTraineeDetails(Model model){
		ArrayList<Trainee> list=new ArrayList<Trainee>();
		list=ITraineeService.retrieveAllTrainee();
		model.addAttribute("traineeDetails",list);
		return "allTraineeList";
		
	}
	
	
	@RequestMapping (value="/delete")
	public String showDeletePage(Model model){
		model.addAttribute("trainee1",trainee);//retrieve()
		return "delete";
	}
	
	@RequestMapping (value="/FDeleteTrainee")
	public String showDeleteTraineeData(@ModelAttribute("trainee1") Trainee trainee,Model model)
	{
		int traineeId =trainee.getTraineeId();
		this.trainee= ITraineeService.retrieveTrainee(traineeId);
		model.addAttribute("trainee", this.trainee);
		//model.addAttribute("trainee1", this.trainee);
		return "delete";
	}
	
	@RequestMapping (value="/deleted")
	public String showDeletedDetail(){
		System.out.println(trainee);
		boolean trainee=ITraineeService.deleteTrainee(this.trainee.getTraineeId());
		return "deleted";
	}
	
	
	@RequestMapping (value="/modify")
	public String showModify(Model model){
		/*model.addAttribute("traineeId",trainee);
		model.addAttribute("traineeName",trainee);*/
		model.addAttribute("trainee",trainee);
		model.addAttribute("taineeDetails",trainee);
		//model.addAttribute("traineeDomain",trainee);s
		return "modify";
	}
	
	@RequestMapping (value="/FModifyTrainee")
	public String showMTraineeData(@ModelAttribute("trainee") Trainee trainee1,Model model)
	{
		int traineeId=trainee1.getTraineeId(); 
		Trainee tr = ITraineeService.retrieveTrainee(traineeId);
		System.out.println(trainee);
		//this.trainee=ITraineeService.modifyTrainee(trainee.getTraineeId());
		System.out.println(tr);
		model.addAttribute("trainee",trainee);
		model.addAttribute("traineeDetails",tr);
		return "modify";
	}
	
	@RequestMapping (value="/modifyDetails")
	public String showModifyData(Trainee traineeDetails,Model model){
		System.out.println(traineeDetails);
		boolean flag = ITraineeService.modifyTrainee(traineeDetails);
		if(flag == false)
		{
			model.addAttribute("taineeDetails",this.trainee);
			return "modify";
		}
		else
		{
			return "modified";
		}
		
	}
	
	
}



