package com.cg.trainee.service;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.dao.ITraineeRepositoryDao;
import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;



@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	private ITraineeRepositoryDao ITraineeRepositoryDao;
	
	@Override
	public boolean addTrainee(Trainee trainee)throws TraineeException {
		// TODO Auto-generated method stub
		return ITraineeRepositoryDao.addTrainee(trainee);
	}

	@Override
	public boolean deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		return ITraineeRepositoryDao.deleteTrainee(traineeId);
	}


	@Override
	public Trainee retrieveTrainee(int traineeId) {
		// TODO Auto-generated method stub
		return ITraineeRepositoryDao.retrieveTrainee(traineeId);
	}

	@Override
	public ArrayList<Trainee> retrieveAllTrainee() {
		// TODO Auto-generated method stub
		return ITraineeRepositoryDao.retrieveAllTrainee();
	}

	@Override
	public boolean modifyTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return ITraineeRepositoryDao.modifyTrainee(trainee);
	}



}
