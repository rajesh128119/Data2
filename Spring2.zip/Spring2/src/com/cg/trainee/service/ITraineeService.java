package com.cg.trainee.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.trainee.entities.Trainee;
import com.cg.trainee.exception.TraineeException;

public interface ITraineeService {
	boolean addTrainee(Trainee trainee) throws TraineeException;
	public boolean modifyTrainee(Trainee trainee);
	boolean deleteTrainee(int traineeId);
	public Trainee retrieveTrainee(int traineeId);
	public ArrayList<Trainee> retrieveAllTrainee();
	
}
