package org.apache.log4j;

import com.capgemini.cabs.loggers.MyLoggers;

public class Logger {
	public static  MyLoggers getLoggerInstance()
	{
		MyLoggers logger = null;
		return logger;
	}


}
