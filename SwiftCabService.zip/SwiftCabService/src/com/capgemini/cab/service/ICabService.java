package com.capgemini.cab.service;

import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;

public interface ICabService {
//declaring all methods that are requires in interface
int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException;
boolean getRequestdetails(CabRequest bean) throws CabRequestException;
public String getId() throws CabRequestException;
public String cab_Numbers() throws CabRequestException;
public boolean validateCustomerName(String customerName);
boolean validatePhoneNumber(String phoneNumber);
public Boolean validateAddress(String address);
boolean validatePincode(String pincode);



}
