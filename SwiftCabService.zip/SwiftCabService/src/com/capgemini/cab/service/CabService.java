package com.capgemini.cab.service;

import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;


public class CabService implements ICabService {           
	//This Class implements it's interface and return respective results
	ICabService dao;
	public void setDao(ICabService dao) {
		this.dao = dao;
	}
	
	
	public CabService()
	{
		dao = new CabService();
	}

	@Override
	public int addCabRequestDetails(CabRequest cabRequest) throws CabRequestException {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public String getId() throws CabRequestException {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String cab_Numbers() throws CabRequestException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public boolean validateCustomerName(String customerName) {
		//Validating CustomerName
		return customerName.matches("[A-Z]{1}[a-zA-Z]{2,20}"); 
	}

	@Override
	public boolean validatePhoneNumber(String phoneNumber) {
		//Validating Phone Number
		return phoneNumber.matches("[7-9]{1}[0-9]{9}");
	}

	@Override
	public Boolean validateAddress(String address) {
		//Validating address
		return address.matches("[A-Z]{1}[a-z]{10,20}&");
	}


	@Override
	public boolean validatePincode(String pincode) {
		// TODO Auto-generated method stub
		return pincode.matches("[3-5]{1}[0-9]{5}") ;
	}


	@Override
	public boolean getRequestdetails(CabRequest bean)
			throws CabRequestException {
		// TODO Auto-generated method stub
		return null != null;
	}






}
