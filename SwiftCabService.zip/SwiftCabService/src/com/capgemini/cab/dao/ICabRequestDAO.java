package com.capgemini.cab.dao;

import com.capgemini.cabs.bean.CabRequest;

public interface ICabRequestDAO {
  boolean addCabRequestDetails(CabRequest cabRequest);
CabRequest getRequestDetails(int requestId);
}
