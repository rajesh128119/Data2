package com.capgemini.cab.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cabs.bean.CabRequest;
import com.capgemini.cabs.dbutil.DButil;
import com.capgemini.cabs.loggers.MyLoggers;





public class CabRequestDAO implements ICabRequestDAO {
	MyLoggers logger=MyLoggers.getLoggerInstance();//logger
	Connection con;
	boolean flag = false;
	public void ICabRequestDAO() {
		con = DButil.getConnection();
		if(con!=null)
		{
			//logger.info("Obtailned Connection");//logger
		}
	}

	@Override
	public boolean addCabRequestDetails(CabRequest cabRequest){
		boolean flag = false;
		try
		{
		//Inserting cab request details to database through customer
		String sql = "INSERT INTO cab_request  VALUES(seq_request_id,?,?,?,?)";
		PreparedStatement pstmt = con.prepareStatement(sql);
		pstmt.setString(1,cabRequest.getCustomerName());
		pstmt.setString(2,cabRequest.getPhoneNumber());
		pstmt.setString(3,cabRequest.getAddress());
		pstmt.setString(4,cabRequest.getPincode());
		int row = pstmt.executeUpdate();
		if (row == 0)
			{
				try {
					throw new CabRequestException("Cab Request details are not Inserted");
				} catch (CabRequestException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		else
		{	//Getting Cab RequestId
			System.out.println("Your cab request has been successfully registerd,your requestID is:get(request_id)");
			flag=true;
		}
		}
		catch(SQLException e)
		{
		e.getMessage();
		}
		
		return flag;
	}

	@Override
	public CabRequest getRequestDetails(int requestId) {
	//viewing cabRequest Status
		PreparedStatement pstmt;
		CabRequest bean = null;
		try{
			pstmt = con.prepareStatement("SELECT customer_name,request_status,cab_number,address_of_pickup FROM cab_request  WHERE request_id=?");
			pstmt.setInt(1,requestId);
			ResultSet result= pstmt.executeQuery();
			if(result.next())
			{
				bean= new CabRequest();
				bean.setCustomerName(result.getString(1));
				bean.setRequest_status(result.getString(2));
				bean.setCab_number(result.getString(3));
				bean.setAddress_of_pickup(result.getString(4));
				//logger.info("Fetched Record"+bean);//logger
			}
			else {
				try {
					throw new CabRequestException("Request with" + requestId+ "not found");
				} catch (CabRequestException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}catch(SQLException e)
		{
			e.getMessage();
			/*logger.error("exception occured"+e.getMessage());
			throw new CabRequestException(e.getMessage());
		 */
		}
	
		return bean;
	}

}
