package com.capgemini.cab.exception;

public class CabRequestException extends Exception {
	String message;
	public CabRequestException(String message)
	{
		this.message=message;
	}
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return super.getMessage();
	}
	
}
