package com.capgemini.cabs.loggers;



public class MyLoggers {

	public static  MyLoggers getLoggerInstance()
	{
		MyLoggers logger = null;
		return logger;
	}

}
