package com.capgemini.cabs.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import com.capgemini.cab.service.CabService;
import com.capgemini.cabs.bean.CabRequest;
public class ICabrequestDAOTest {
	@Before
	public void init()
	{
		CabService service = new CabService();
		CabService dao = new CabService();
		service.setDao(dao);
	}

	@Test
	public void testICabRequestDAO() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddCabRequestDetails() {
		CabRequest bean=new CabRequest();
		bean.setCustomerName("Rajesh");
		bean.setPhoneNumber("8596547854");
		bean.setAddress_of_pickup("Capgemini Knowledge Park , IT1/IT2, TTC Industrial area Airoli");
		bean.setPincode("452587");
		/*try{
		Object service;
		assertEquals(false,service.getRequestDetails(bean));//service.insertDetails(bean));
		}
		catch(CabRequestException e)
		{
			System.out.println(e.getMessage());
		}
		*/
	}

	

	@Test
	public void testGetRequestDetails() {
		fail("Not yet implemented");
	}

}
