package com.capgemini.cabs.ui;


import java.util.Scanner;

import com.capgemini.cab.exception.CabRequestException;
import com.capgemini.cab.service.CabService;
import com.capgemini.cab.service.ICabService;
import com.capgemini.cabs.bean.CabRequest;



public class Client {

	public static void main(String[] args) {
		int choice=0;
		boolean flag=false;
		ICabService service= new CabService();
		try(Scanner sc = new Scanner(System.in))
		{
			do{
				System.out.println("1-Raise Cab Request");
				System.out.println("2-View Cab Request Status");
				System.out.println("3-Exit");
				System.out.println("Enter ur choice");
				choice=sc.nextInt();
				switch(choice)
				{
				case 1:
							//Insertion Of Data From user 
							String customerName = null;
							String phoneNumber = null;
							String address = null;
				
							//Validating Inserting data with pattern 
							while(!flag)
							{
							System.out.println("Enter Your Name");
							customerName=sc.next();
							flag=service.validateCustomerName(customerName);
							if(flag==false)
							{
								System.out.println("Invalid Name re-enter it");
							}
							}
							//Validating Inserting data with pattern 
							while(!flag)
							{
							System.out.println("Enter Your Phone Number");
							phoneNumber=sc.next();
							flag=service.validatePhoneNumber(phoneNumber);
							if(flag==false)
							{
								System.out.println("Invalid PhoneNumber re-enter it");
							}
							}
							//Validating Inserting data with pattern 
							while(!flag)
							{
							System.out.println("Enter Your Address");
							address=sc.next();
							flag=service.validateAddress(address);
							if(flag==false)
							{
								System.out.println("Invalid address re-enter it");
							}
							}
							//Validating Inserting data with pattern 
							while(!flag)
							{
							System.out.println("Enter Your Pincode");
							String pincode1 = sc.next();
							flag=service.validatePincode(pincode1);
							if(flag==false)
							{
								System.out.println("Invalid Pincode re-enter it");
							}
							}
							CabRequest bean= new CabRequest();
							bean.setCustomerName(customerName);
							bean.setPhoneNumber(phoneNumber);
							bean.setAddress(address);
							bean.setPincode(null);
							try{
								boolean flag1=service.getRequestdetails(bean);
								if(flag)
								{
									System.out.println("Inserted Successfully");
								}
							}
							catch(CabRequestException e)
							{
								e.getMessage();
							}
							
							break;
							
				case 2:
					
					
				case 3:	
							System.out.println("exit");
							break;
				default:	System.out.println("wrong choice");		
				}
				System.out.println("do u want to continue");
			}
			while(choice!=0);
		}


	}

}
