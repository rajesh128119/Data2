package com.capgemini.cabs.bean;

public class CabRequest {
	//Declaring fields which requires
String customerName;
String phoneNumber;
String address;
String pincode;
String address_of_pickup;
String request_status;
String cab_number;

//Generating all fields Getters and setters

public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getPincode() {
	return pincode;
}
public void setPincode(String pincode) {
	this.pincode = pincode;
}

public String getAddress_of_pickup() {
	return address_of_pickup;
}
public void setAddress_of_pickup(String address_of_pickup) {
	this.address_of_pickup = address_of_pickup;
}
public String getRequest_status() {
	return request_status;
}
public void setRequest_status(String request_status) {
	this.request_status = request_status;
}
public String getCab_number() {
	return cab_number;
}
public void setCab_number(String cab_number) {
	this.cab_number = cab_number;

}

//ToString()
@Override
public String toString() {
	return "CabRequest [customerName=" + customerName + ", phoneNumber="
			+ phoneNumber + ", address=" + address + ", pincode=" + pincode
			+ ", address_of_pickup=" + address_of_pickup + ", request_status="
			+ request_status + ", cab_number=" + cab_number + "]";
}
}
